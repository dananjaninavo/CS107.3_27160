﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class ConvertValues
    {
        public void kilometerTOmeter(double km)
        {
            double m = km * 1000;
            Console.WriteLine(m.ToString()+"m");
        }
    }
}
