﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class SayHello
    {
        private void sayHello()
        {
            Console.WriteLine("hello world");
            Console.ReadKey();
        }
    }
}
